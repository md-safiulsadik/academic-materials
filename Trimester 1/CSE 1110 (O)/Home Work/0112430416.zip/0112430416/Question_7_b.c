#include <stdio.h>

int main()
{
    float width, length, road_width, garden_perimeter;

    printf("Enter the width of the garden: ");
    scanf("%f", &width);
    printf("Enter the length of garden: ");
    scanf("%f", &length);
    printf("Enter the width of the road surrounding the garden: ");
    scanf("%f", &road_width);

    garden_perimeter = 2*(width + length); 
    
    printf("Perimeter the garden is: %.02f square meters\n", garden_perimeter);

    return 0;
}