#include <stdio.h>

int main()
{
    printf("My name is Md. Safiul Kafi Sadik.\n");
    printf("My faculty is Md. Fahim Bin Amin.\n");
    printf("I am learning \"C\" programming language.\n");
    printf("/\\C/\\ Programming language is easier to understand!\n");

    return 0;
}