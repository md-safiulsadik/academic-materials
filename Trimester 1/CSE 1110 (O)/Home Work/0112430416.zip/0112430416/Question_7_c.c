#include <stdio.h>

int main()
{
    float width, length, road_width, cost_per_sqr, total_cost;
    float garden_area, garden_area_with_road, road_area;

    printf("Enter the width of the garden: ");
    scanf("%f", &width);
    printf("Enter the length of garden: ");
    scanf("%f", &length);
    printf("Enter the width of the road surrounding the garden: ");
    scanf("%f", &road_width);
    printf("Cost per square meter: ");
    scanf("%f", &cost_per_sqr);

    garden_area = width * length;
    garden_area_with_road = ((2*road_width) + width) * ((2*road_width) + length);
    road_area = garden_area_with_road - garden_area;
    total_cost = road_area * cost_per_sqr;
    
    printf("The total cost paving the garden is: %.02f tk\n", total_cost);

    return 0;
}