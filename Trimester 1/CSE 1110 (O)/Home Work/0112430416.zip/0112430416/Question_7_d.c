#include <stdio.h>

int main()
{
    float width, length, height, dimensions;

    printf("Enter the width: ");
    scanf("%f", &width);
    printf("Enter the length: ");
    scanf("%f", &length);
    printf("Enter the height: ");
    scanf("%f", &height);

    dimensions = width * length * height;

    printf("The dimensions of the box is: %.02f meter qube", dimensions);

    return 0;
}