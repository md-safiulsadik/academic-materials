#include <stdio.h>

int main()
{
    printf(
    "My name is Md. Safiul Kafi Sadik\nMy faculty is Md. Fahim Bin Amin.\nI am learning \"C\" programming language.\n/\\C/\\ Programming language is easier to understand!"
    );

    return 0;
}