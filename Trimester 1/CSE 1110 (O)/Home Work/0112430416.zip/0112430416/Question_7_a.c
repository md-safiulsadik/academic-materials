#include <stdio.h>

int main()
{
    float width, length, road_width;
    float garden_area, garden_area_with_road, road_area;

    printf("Enter the width of the garden: ");
    scanf("%f", &width);
    printf("Enter the length of garden: ");
    scanf("%f", &length);
    printf("Enter the width of the road surrounding the garden: ");
    scanf("%f", &road_width);

    garden_area = width * length;
    garden_area_with_road = ((2*road_width) + width) * ((2*road_width) + length);
    road_area = garden_area_with_road - garden_area;
    
    printf("Area of the path surrounding the garden is: %.02f square meters\n", road_area);

    return 0;
}