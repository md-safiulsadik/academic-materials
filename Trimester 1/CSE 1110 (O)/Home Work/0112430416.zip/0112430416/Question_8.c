#include <stdio.h>

int main()
{
    int n;
    float sum = 0;

    printf("How many numbers you want to input? ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++)
    {
        float num = 0;
        printf("Enter the number no.%d: ", i + 1);
        scanf("%f", &num);
        sum += num;
    }
       
    float avrg = sum / n;
    printf("The average of the numbers is: %.02f", avrg);

    return 0;
}