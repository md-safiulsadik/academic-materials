#include <stdio.h>

int main()
{
    float mark;

    printf("Input mark: ");
    scanf("%f", &mark);

    if (mark < 55)
    {
        printf("F (Fail)");
    }
    else if (89 < mark && mark <101)
    {
        printf("A (Plain)");
    }
    else if (85 < mark && mark < 90)
    {
        printf("A- (Minus)");
    }
    else if (81 < mark && mark < 86)
    {
        printf("B+ (Plus)");
    }
    else if (77 < mark && mark < 82)
    {
        printf("B (Plain)");
    }
    else if (73 < mark && mark < 78)
    {
        printf("B- (Minus)");
    }
    else if (69 < mark && mark < 74)
    {
        printf("C+ (Plus)");
    }
    else if (65 < mark && mark < 70)
    {
        printf("C (Plain)");
    }
    else if (61 < mark && mark < 66)
    {
        printf("C- (Minus)");
    }
    else if (57 < mark && mark < 62)    
    {
        printf("D+ (Plus)");
    }
    else if (54 < mark && mark < 58)
    {
        printf("D (Plain)");
    }
    else
    {
        printf("Invaild input\nPlease check you input");
    }

    printf("\n");
    return 0;
}