#include <stdio.h>

int main()
{
    int num1 = 5, num2 = 10, sum;

    sum = num1 + num2;
    printf("Sum: %d", sum);

    return 0;
}