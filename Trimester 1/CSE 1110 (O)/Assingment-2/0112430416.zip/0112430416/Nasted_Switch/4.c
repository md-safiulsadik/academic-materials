#include <stdio.h>

int main()
{
    int a, b, c;
    scanf("%d%d%d", &a, &b, &c);

    switch (a + b + c == 180)
    {
    case 1:
        switch (1)
        {
        case 1:
            printf("YES\n");
            break;
        }
        break;
    case 0:
        switch (1)
        {
        case 1:
            printf("NO\n");
            break;
        }
        break;
    }

    return 0;
}
