#include <stdio.h>

int main()
{
    int n, m;
    scanf("%d %d", &n, &m);

    switch (n < m)
    {
        case 1:
            switch (1)
            {
                case 1:
                    printf("%d is less than %d\n", n, m);
                    break;
            }
            break;
        case 0:
            switch (n > m)
            {
                case 1:
                    switch (1)
                    {
                        case 1:
                            printf("%d is greater than %d\n", n, m);
                            break;
                    }
                    break;
                case 0:
                    switch (1)
                    {
                        case 1:
                            printf("%d is equal to %d\n", n, m);
                            break;
                    }
                    break;
            }
            break;
    }

    return 0;
}
