#include<stdio.h>

int main()
{   
    int n;
    scanf("%d", &n);

    switch (n > 0 && (n & (n - 1)) == 0)
    {
        case 1:
            switch (1)
            {
                case 1:
                    printf("YES\n");
                    break;
            }
            break;
        case 0:
            switch (1)
            {
                case 1:
                    printf("NO\n");
                    break;
            }
            break;
    }

    return 0;
}
