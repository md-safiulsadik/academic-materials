#include <stdio.h>

int main()
{
    int year;
    scanf("%d", &year);

    switch ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
    {
        case 1:
            switch (1)
            {
                case 1:
                    printf("%d is a leap year.\n", year);
                    break;
            }
            break;
        case 0:
            switch (1)
            {
                case 1:
                    printf("%d is not a leap year.\n", year);
                    break;
            }
            break;
    }

    return 0;
}
