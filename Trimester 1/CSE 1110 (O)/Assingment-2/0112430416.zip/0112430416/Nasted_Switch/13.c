#include <stdio.h>

int main()
{
    double a, b;
    int choice, case_choice;

    scanf("%lf %lf", &a, &b);

    printf("1. Addition\n");
    printf("2. Subtraction\n");
    printf("3. Multiplication\n");
    printf("4. Division\n");

    scanf("%d", &choice);

    switch (choice)
    {
    case 1:
        switch (1)
        {
        case 1:
            printf("Addition: %.2lf\n", a + b);
            break;
        }
        break;
    case 2:
        switch (1)
        {
        case 1:
            printf("Subtraction: %.2lf\n", a - b);
            break;
        }
        break;
    case 3:
        switch (1)
        {
        case 1:
            printf("Multiplication: %.2lf\n", a * b);
            break;
        }
        break;
    case 4:
        switch (1)
        {
        case 1:
            printf("1. Quotient\n");
            printf("2. Remainder\n");
            scanf("%d", &case_choice);
            switch (case_choice)
            {
            case 1:
                switch (b != 0)
                {
                case 1:
                    switch (1)
                    {
                    case 1:
                        printf("Quotient: %.0lf\n", a / b);
                        break;
                    }
                    break;
                case 0:
                    switch (1)
                    {
                    case 1:
                        printf("Error: Division by zero is not allowed.\n");
                        break;
                    }
                    break;
                }
                break;
            case 2:
                switch (b != 0)
                {
                case 1:
                    switch (1)
                    {
                    case 1:
                        int remainder = ((int)a) % ((int)b);
                        printf("Remainder: %d\n", remainder);
                        break;
                    }
                    break;
                case 0:
                    switch (1)
                    {
                    case 1:
                        printf("Error: Division by zero is not allowed.\n");
                        break;
                    }
                    break;
                }
                break;
            default:
                switch (1)
                {
                case 1:
                    printf("Invalid choice. Please try again.\n");
                    break;
                }
                break;
            }
            break;
        }
        break;
    default:
        switch (1)
        {
        case 1:
            printf("Invalid choice. Please try again.\n");
            break;
        }
        break;
    }

    return 0;
}
