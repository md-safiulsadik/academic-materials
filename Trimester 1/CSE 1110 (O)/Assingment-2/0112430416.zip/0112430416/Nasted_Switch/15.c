#include <stdio.h>

int main()
{
    int X, n1, n2, n3;
    int flag = 0;

    scanf("%d", &X);
    scanf("%d", &n1);

    switch (n1 == X)
    {
        case 1:
            switch (1)
            {
                case 1:
                    printf("Right, Player-2 wins!\n");
                    flag = 1;
                    break;
            }
            break;
        case 0:
            switch (1)
            {
                case 1:
                    printf("Wrong, 2 Chance(s) Left!\n");
                    break;
            }
            break;
    }

    switch (!flag)
    {
        case 1:
            switch (1)
            {
                case 1:
                    printf("Player-2, enter your second guess: ");
                    scanf("%d", &n2);
                    switch (n2 == X)
                    {
                        case 1:
                            switch (1)
                            {
                                case 1:
                                    printf("Right, Player-2 wins!\n");
                                    flag = 1;
                                    break;
                            }
                            break;
                        case 0:
                            switch (1)
                            {
                                case 1:
                                    printf("Wrong, 1 Chance(s) Left!\n");
                                    break;
                            }
                            break;
                    }
                    break;
            }
            break;
    }

    switch (!flag)
    {
        case 1:
            switch (1)
            {
                case 1:
                    printf("Player-2, enter your third guess: ");
                    scanf("%d", &n3);
                    switch (n3 == X)
                    {
                        case 1:
                            switch (1)
                            {
                                case 1:
                                    printf("Right, Player-2 wins!\n");
                                    flag = 1;
                                    break;
                            }
                            break;
                        case 0:
                            switch (1)
                            {
                                case 1:
                                    printf("Wrong, 0 Chance(s) Left!\n");
                                    break;
                            }
                            break;
                    }
                    break;
            }
            break;
    }

    switch (!flag)
    {
        case 1:
            switch (1)
            {
                case 1:
                    printf("Player-1 wins!\n");
                    break;
            }
            break;
    }

    return 0;
}
