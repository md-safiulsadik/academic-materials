#include <stdio.h>

int main()
{
    int n;
    scanf("%d", &n);

    switch (n < 0)
    {
    case 1:
        switch (1)
        {
        case 1:
            printf("Negative\n");
            break;
        }
        break;
    case 0:
        switch (1)
        {
        case 1:
            printf("Positive\n");
            break;
        }
        break;
    }

    return 0;
}
