#include <stdio.h>

int main()
{
    double number1, number2;
    char operator;

    scanf("%lf", &number1);
    scanf(" %c", &operator);
    scanf("%lf", &number2);

    switch (operator)
    {
        case '+':
            switch (1)
            {
                case 1:
                    printf("Addition: %.2lf\n", number1 + number2);
                    break;
            }
            break;
        case '-':
            switch (1)
            {
                case 1:
                    printf("Subtraction: %.2lf\n", number1 - number2);
                    break;
            }
            break;
        case '*':
            switch (1)
            {
                case 1:
                    printf("Multiplication: %.2lf\n", number1 * number2);
                    break;
            }
            break;
        case '/':
            switch (number2 != 0)
            {
                case 1:
                    switch (1)
                    {
                        case 1:
                            printf("Division: %.6lf\n", number1 / number2);
                            break;
                    }
                    break;
                case 0:
                    switch (1)
                    {
                        case 1:
                            printf("Division: Zero as divisor is not valid!\n");
                            break;
                    }
                    break;
            }
            break;
        default:
            switch (1)
            {
                case 1:
                    printf("Invalid operator. Please try again.\n");
                    break;
            }
            break;
    }

    return 0;
}
