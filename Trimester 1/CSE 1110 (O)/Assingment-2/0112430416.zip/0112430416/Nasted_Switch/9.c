#include <stdio.h>

int main()
{
    char ch;
    scanf("%c", &ch);

    switch ((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z'))
    {
        case 1:
            switch (1)
            {
                case 1:
                    printf("%c Alphabet\n", ch);
                    break;
            }
            break;
        case 0:
            switch (ch >= '0' && ch <= '9')
            {
                case 1:
                    switch (1)
                    {
                        case 1:
                            printf("%c Digit\n", ch);
                            break;
                    }
                    break;
                case 0:
                    switch (1)
                    {
                        case 1:
                            printf("%c Special\n", ch);
                            break;
                    }
                    break;
            }
            break;
    }

    return 0;
}
