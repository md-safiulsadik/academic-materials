#include <stdio.h>

int main()
{
    float a, b;
    int choice, caseChoice;

    scanf("%f %f", &a, &b);
    scanf("%d", &choice);

    switch (choice)
    {
        case 1:
            switch (1)
            {
                case 1:
                    printf("Addition: %.2f\n", a + b);
                    break;
            }
            break;
        case 2:
            switch (1)
            {
                case 1:
                    printf("Subtraction: %.2f\n", a - b);
                    break;
            }
            break;
        case 3:
            switch (1)
            {
                case 1:
                    printf("Multiplication: %.2f\n", a * b);
                    break;
            }
            break;
        case 4:
            switch (b != 0)
            {
                case 1:
                    switch (1)
                    {
                        case 1:
                            scanf("%d", &caseChoice);
                            switch (caseChoice)
                            {
                                case 1:
                                    switch (1)
                                    {
                                        case 1:
                                            printf("Quotient: %.2f\n", a / b);
                                            break;
                                    }
                                    break;
                                case 2:
                                    switch (1)
                                    {
                                        case 1:
                                            printf("Remainder: %.2f\n", (float)((int)a % (int)b));
                                            break;
                                    }
                                    break;
                                default:
                                    switch (1)
                                    {
                                        case 1:
                                            printf("Invalid case choice.\n");
                                            break;
                                    }
                                    break;
                            }
                            break;
                    }
                    break;
                case 0:
                    switch (1)
                    {
                        case 1:
                            printf("Error: Divisor is zero\n");
                            break;
                    }
                    break;
            }
            break;
        default:
            switch (1)
            {
                case 1:
                    printf("Invalid choice.\n");
                    break;
            }
            break;
    }

    return 0;
}
