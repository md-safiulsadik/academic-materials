#include <stdio.h>

int main()
{
    int n;
    scanf("%d", &n);

    if (n == 0)
    {
        printf("Zero is not a valid input\n");
    }
    else if (n < 0)
    {
        printf("Negative is not a valid input\n");
    }
    else if (n & (n - 1) == 0)
    {
        printf("YES\n");
    }
    else
    {
        printf("NO\n");
    }

    return 0;
}