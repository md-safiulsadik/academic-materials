#include <stdio.h>

int main()
{
    double number1, number2;
    char operator;

    scanf("%lf", &number1);
    scanf(" %c", &operator);
    scanf("%lf", &number2);

    if (operator== '+')
    {
        printf("Addition: %.2lf\n", number1 + number2);
    }
    else if (operator== '-')
    {
        printf("Subtraction: %.2lf\n", number1 - number2);
    }
    else if (operator== '*')
    {
        printf("Multiplication: %.2lf\n", number1 * number2);
    }
    else if (operator== '/')
    {
        if (number2 != 0)
        {
            printf("Division: %.6lf\n", number1 / number2);
        }
        else
        {
            printf("Division: Zero as divisor is not valid!\n");
        }
    }
    else
    {
        printf("Invalid operator. Please try again.\n");
    }

    return 0;
}