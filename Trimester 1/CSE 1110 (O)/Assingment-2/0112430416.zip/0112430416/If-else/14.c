#include <stdio.h>

int main()
{
    float a, b;
    int choice, caseChoice;

    scanf("%f %f", &a, &b);
    scanf("%d", &choice);

    if (choice == 1)
    {
        printf("Addition: %.2f\n", a + b);
    }
    else if (choice == 2)
    {
        printf("Subtraction: %.2f\n", a - b);
    }
    else if (choice == 3)
    {
        printf("Multiplication: %.2f\n", a * b);
    }
    else if (choice == 4)
    {
        if (b != 0)
        {
            scanf("%d", &caseChoice);

            if (caseChoice == 1)
            {
                printf("Quotient: %.2f\n", a / b);
            }
            else if (caseChoice == 2)
            {
                printf("Remainder: %.2f\n", (float)((int)a % (int)b));
            }
            else
            {
                printf("Invalid case choice.\n");
            }
        }
        else
        {
            printf("Error: Divisor is zero\n");
        }
    }
    else
    {
        printf("Invalid choice.\n");
    }

    return 0;
}