#include<stdio.h>

int main()
{   
    int n;
    scanf("%d", &n);

    switch (n > 0 && (n & (n - 1)) == 0)
    {
        case 1:
            printf("YES\n");
            break;
        case 0:
            printf("NO\n");
            break;
    }

    return 0;
}
