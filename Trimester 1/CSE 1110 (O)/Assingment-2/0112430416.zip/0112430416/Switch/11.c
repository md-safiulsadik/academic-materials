#include <stdio.h>

int main()
{
    double score;

    scanf("%lf", &score);

    switch (score >= 90 && score <= 100)
    {
    case 1:
        printf("Grade: A\n");
        break;
    case 0:
        switch (score >= 86 && score <= 89)
        {
        case 1:
            printf("Grade: A-\n");
            break;
        case 0:
            switch (score >= 82 && score <= 85)
            {
            case 1:
                printf("Grade: B+\n");
                break;
            case 0:
                switch (score >= 78 && score <= 81)
                {
                case 1:
                    printf("Grade: B\n");
                    break;
                case 0:
                    switch (score >= 74 && score <= 77)
                    {
                    case 1:
                        printf("Grade: B-\n");
                        break;
                    case 0:
                        switch (score >= 70 && score <= 73)
                        {
                        case 1:
                            printf("Grade: C+\n");
                            break;
                        case 0:
                            switch (score >= 66 && score <= 69)
                            {
                            case 1:
                                printf("Grade: C\n");
                                break;
                            case 0:
                                switch (score >= 62 && score <= 65)
                                {
                                case 1:
                                    printf("Grade: C-\n");
                                    break;
                                case 0:
                                    switch (score >= 58 && score <= 61)
                                    {
                                    case 1:
                                        printf("Grade: D+\n");
                                        break;
                                    case 0:
                                        switch (score >= 55 && score <= 57)
                                        {
                                        case 1:
                                            printf("Grade: D\n");
                                            break;
                                        case 0:
                                            printf("Grade: F\n");
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    return 0;
}
