#include <stdio.h>

int main()
{
    double a, b;
    int choice, case_choice;

    scanf("%lf %lf", &a, &b);

    printf("1. Addition\n");
    printf("2. Subtraction\n");
    printf("3. Multiplication\n");
    printf("4. Division\n");

    scanf("%d", &choice);

    switch (choice)
    {
    case 1:
        printf("Addition: %.2lf\n", a + b);
        break;
    case 2:
        printf("Subtraction: %.2lf\n", a - b);
        break;
    case 3:
        printf("Multiplication: %.2lf\n", a * b);
        break;
    case 4:
        printf("1. Quotient\n");
        printf("2. Remainder\n");
        scanf("%d", &case_choice);

        switch (case_choice)
        {
        case 1:
            if (b != 0)
            {
                printf("Quotient: %.0lf\n", a / b);
            }
            else
            {
                printf("Error: Division by zero is not allowed.\n");
            }
            break;
        case 2:
            if (b != 0)
            {
                int remainder = ((int)a) % ((int)b);
                printf("Remainder: %d\n", remainder);
            }
            else
            {
                printf("Error: Division by zero is not allowed.\n");
            }
            break;
        default:
            printf("Invalid choice. Please try again.\n");
            break;
        }
        break;
    default:
        printf("Invalid choice. Please try again.\n");
        break;
    }

    return 0;
}
