#include <stdio.h>

int main()
{
    float a, b;
    int choice, caseChoice;

    scanf("%f %f", &a, &b);
    scanf("%d", &choice);

    switch (choice)
    {
    case 1:
        printf("Addition: %.2f\n", a + b);
        break;
    case 2:
        printf("Subtraction: %.2f\n", a - b);
        break;
    case 3:
        printf("Multiplication: %.2f\n", a * b);
        break;
    case 4:
        if (b != 0)
        {
            scanf("%d", &caseChoice);

            switch (caseChoice)
            {
            case 1:
                printf("Quotient: %.2f\n", a / b);
                break;
            case 2:
                printf("Remainder: %.2f\n", (float)((int)a % (int)b));
                break;
            default:
                printf("Invalid case choice.\n");
                break;
            }
        }
        else
        {
            printf("Error: Divisor is zero\n");
        }
        break;
    default:
        printf("Invalid choice.\n");
        break;
    }

    return 0;
}
