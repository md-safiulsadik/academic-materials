#include <stdio.h>

int main()
{
    double a, b;
    int choice;

    scanf("%lf %lf", &a, &b);
    scanf("%d", &choice);

    switch (choice)
    {
    case 1:
        printf("Addition: %.2lf\n", a + b);
        break;
    case 2:
        printf("Subtraction: %.2lf\n", a - b);
        break;
    case 3:
        printf("Multiplication: %.2lf\n", a * b);
        break;
    case 4:
        if (b != 0)
        {
            printf("Quotient: %.2lf\n", a / b);
        }
        else
        {
            printf("Error: Division by zero is not allowed.\n");
        }
        break;
    default:
        printf("Invalid choice. Please try again.\n");
        break;
    }

    return 0;
}
