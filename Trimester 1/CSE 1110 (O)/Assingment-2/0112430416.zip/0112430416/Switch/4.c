#include<stdio.h>

int main()
{
    int a, b, c;
    scanf("%d%d%d", &a, &b, &c);

    switch (a + b + c == 180)
    {
        case 1:
            printf("YES\n");
            break;
        case 0:
            printf("NO\n");
            break;
    }

    return 0;
}
