#include <stdio.h>

int main()
{
    int n, m;
    scanf("%d %d", &n, &m);

    switch (n < m)
    {
    case 1:
        printf("%d is less than %d\n", n, m);
        break;
    case 0:
        switch (n > m)
        {
        case 1:
            printf("%d is greater than %d\n", n, m);
            break;
        case 0:
            printf("%d is equal to %d\n", n, m);
            break;
        }
        break;
    }

    return 0;
}
