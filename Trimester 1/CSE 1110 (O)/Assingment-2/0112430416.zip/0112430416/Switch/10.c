#include <stdio.h>

int main()
{
    double number1, number2;
    char operator;

    scanf("%lf", &number1);
    scanf(" %c", &operator);
    scanf("%lf", &number2);

    switch (operator)
    {
        case '+':
            printf("Addition: %.2lf\n", number1 + number2);
            break;
        case '-':
            printf("Subtraction: %.2lf\n", number1 - number2);
            break;
        case '*':
            printf("Multiplication: %.2lf\n", number1 * number2);
            break;
        case '/':
            if (number2 != 0)
            {
                printf("Division: %.6lf\n", number1 / number2);
            }
            else
            {
                printf("Division: Zero as divisor is not valid!\n");
            }
            break;
        default:
            printf("Invalid operator. Please try again.\n");
            break;
    }

    return 0;
}
