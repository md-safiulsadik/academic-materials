#include <stdio.h>

int main()
{
    int X, n1, n2, n3;
    int flag = 0;

    scanf("%d", &X);
    scanf("%d", &n1);

    switch (n1 == X)
    {
    case 1:
        printf("Right, Player-2 wins!\n");
        flag = 1;
        break;
    default:
        printf("Wrong, 2 Chance(s) Left!\n");
        break;
    }

    if (!flag)
    {
        printf("Player-2, enter your second guess: ");
        scanf("%d", &n2);

        switch (n2 == X)
        {
        case 1:
            printf("Right, Player-2 wins!\n");
            flag = 1;
            break;
        default:
            printf("Wrong, 1 Chance(s) Left!\n");
            break;
        }
    }

    if (!flag)
    {
        printf("Player-2, enter your third guess: ");
        scanf("%d", &n3);

        switch (n3 == X)
        {
        case 1:
            printf("Right, Player-2 wins!\n");
            flag = 1;
            break;
        default:
            printf("Wrong, 0 Chance(s) Left!\n");
            break;
        }
    }

    if (!flag)
    {
        printf("Player-1 wins!\n");
    }

    return 0;
}
