#include <stdio.h>

int main()
{
    int n, m;

    if (n < m)
    {
        printf("%d is less than %d\n", n, m);
    }
    else
    {
        if (n > m)
        {
            printf("%d is greater than %d\n", n, m);
        }
        else
        {
            printf("%d is equal to %d\n", n, m);
        }
    }

    return 0;
}
