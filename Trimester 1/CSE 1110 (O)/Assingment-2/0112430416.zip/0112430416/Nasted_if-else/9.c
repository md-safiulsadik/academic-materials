#include <stdio.h>

int main()
{
    char ch;
    scanf("%c", &ch);
    if ((ch >= 'A' && ch <= 'Z'))
    {
        printf("%c Alphabet\n", ch);
    }
    else
    {
        if ((ch >= 'a' && ch <= 'z'))
        {
            printf("%c Alphabet\n", ch);
        }
        else
        {
            if (ch >= '0' && ch <= '9')
            {
                printf("%c Digit\n", ch);
            }
            else
            {
                printf("%c Special\n", ch);
            }
        }
    }
    return 0;
}
